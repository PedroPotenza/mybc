extern int lookahead;

extern FILE *source;

extern int gettoken(FILE *);

extern void T(void);
extern void R(void);
extern void F(void);
extern void Q(void);

extern void match(int);
