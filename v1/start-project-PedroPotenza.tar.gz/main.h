extern int lookahead;

extern int gettoken(FILE *);

extern void E(void);
